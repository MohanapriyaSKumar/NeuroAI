import { Patient } from '@/types/patient';
import { RiskGauge } from './RiskGauge';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Calendar, ChevronRight, TrendingDown, TrendingUp, Minus } from 'lucide-react';

interface PatientCardProps {
  patient: Patient;
  onClick: () => void;
  isSelected?: boolean;
}

const diagnosisBadgeStyles = {
  Normal: 'bg-success/20 text-success border-success/30',
  MCI: 'bg-warning/20 text-warning border-warning/30',
  AD: 'bg-destructive/20 text-destructive border-destructive/30',
};

const TrendIcon = ({ trend }: { trend: 'stable' | 'declining' | 'improving' }) => {
  if (trend === 'declining') return <TrendingDown className="w-3 h-3 text-destructive" />;
  if (trend === 'improving') return <TrendingUp className="w-3 h-3 text-success" />;
  return <Minus className="w-3 h-3 text-muted-foreground" />;
};

export const PatientCard = ({ patient, onClick, isSelected }: PatientCardProps) => {
  const mainCognitiveScore = patient.cognitiveScores[0];

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left card-elevated p-4 transition-all duration-300",
        isSelected && "ring-2 ring-primary border-primary/50"
      )}
    >
      <div className="flex items-center gap-4">
        {/* Risk Gauge */}
        <RiskGauge score={patient.riskScore} level={patient.riskLevel} size="sm" showLabel={false} />
        
        {/* Patient Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-foreground truncate">{patient.name}</h3>
            <Badge className={cn("shrink-0", diagnosisBadgeStyles[patient.diagnosis])}>
              {patient.diagnosis}
            </Badge>
          </div>
          
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>{patient.age}y, {patient.gender}</span>
            <span className="text-xs">ID: {patient.id}</span>
          </div>
          
          <div className="flex items-center gap-4 mt-2">
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-muted-foreground">{mainCognitiveScore.name}:</span>
              <span className="font-mono font-medium text-foreground">
                {mainCognitiveScore.value}/{mainCognitiveScore.maxValue}
              </span>
              <TrendIcon trend={mainCognitiveScore.trend} />
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="w-3 h-3" />
              <span>{new Date(patient.lastAssessment).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
        
        {/* Arrow */}
        <ChevronRight className={cn(
          "w-5 h-5 text-muted-foreground transition-transform",
          isSelected && "text-primary translate-x-1"
        )} />
      </div>
    </button>
  );
};
