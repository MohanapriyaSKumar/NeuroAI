import { cn } from '@/lib/utils';

interface DiagnosisProbabilityProps {
  probabilities: {
    normal: number;
    mci: number;
    ad: number;
  };
}

export const DiagnosisProbability = ({ probabilities }: DiagnosisProbabilityProps) => {
  const categories = [
    { key: 'normal', label: 'Cognitively Normal', color: 'bg-success', value: probabilities.normal },
    { key: 'mci', label: 'Mild Cognitive Impairment', color: 'bg-warning', value: probabilities.mci },
    { key: 'ad', label: "Alzheimer's Disease", color: 'bg-destructive', value: probabilities.ad },
  ];

  const maxProb = Math.max(...categories.map(c => c.value));

  return (
    <div className="space-y-4">
      <h3 className="section-header">
        <span className="w-2 h-2 rounded-full bg-primary" />
        Classification Probabilities
      </h3>
      
      <div className="space-y-3">
        {categories.map((cat) => (
          <div key={cat.key} className="space-y-1.5">
            <div className="flex items-center justify-between text-sm">
              <span className={cn(
                "text-muted-foreground",
                cat.value === maxProb && "text-foreground font-medium"
              )}>
                {cat.label}
              </span>
              <span className={cn(
                "font-mono",
                cat.value === maxProb ? "text-foreground font-semibold" : "text-muted-foreground"
              )}>
                {(cat.value * 100).toFixed(1)}%
              </span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className={cn(
                  "h-full rounded-full transition-all duration-1000 ease-out",
                  cat.color,
                  cat.value === maxProb && "shadow-lg"
                )}
                style={{ width: `${cat.value * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      
      {/* Visual probability distribution */}
      <div className="mt-6 h-4 rounded-full overflow-hidden flex">
        <div 
          className="bg-success transition-all duration-700"
          style={{ width: `${probabilities.normal * 100}%` }}
        />
        <div 
          className="bg-warning transition-all duration-700"
          style={{ width: `${probabilities.mci * 100}%` }}
        />
        <div 
          className="bg-destructive transition-all duration-700"
          style={{ width: `${probabilities.ad * 100}%` }}
        />
      </div>
    </div>
  );
};
