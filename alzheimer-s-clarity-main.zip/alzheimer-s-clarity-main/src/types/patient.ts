export type RiskLevel = 'low' | 'moderate' | 'high';
export type DiagnosisCategory = 'Normal' | 'MCI' | 'AD';

export interface CognitiveScore {
  name: string;
  value: number;
  maxValue: number;
  trend: 'stable' | 'declining' | 'improving';
}

export interface Biomarker {
  name: string;
  value: number;
  unit: string;
  normalRange: { min: number; max: number };
  category: 'normal' | 'elevated' | 'abnormal';
}

export interface FeatureImportance {
  feature: string;
  importance: number;
  direction: 'positive' | 'negative';
  category: 'cognitive' | 'biomarker' | 'imaging' | 'clinical';
}

export interface ProgressionDataPoint {
  month: number;
  cognitiveScore: number;
  predictedScore: number;
  confidenceLower: number;
  confidenceUpper: number;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female';
  riskScore: number;
  riskLevel: RiskLevel;
  diagnosis: DiagnosisCategory;
  diagnosisProbabilities: {
    normal: number;
    mci: number;
    ad: number;
  };
  cognitiveScores: CognitiveScore[];
  biomarkers: Biomarker[];
  featureImportance: FeatureImportance[];
  progressionData: ProgressionDataPoint[];
  lastAssessment: string;
  nextAssessment: string;
  notes: string;
}

export interface DashboardStats {
  totalPatients: number;
  highRiskPatients: number;
  moderateRiskPatients: number;
  lowRiskPatients: number;
  averageRiskScore: number;
  modelAccuracy: number;
  recentAssessments: number;
}
