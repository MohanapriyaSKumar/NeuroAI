import { FeatureImportance } from '@/types/patient';
import { cn } from '@/lib/utils';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface FeatureImportanceChartProps {
  features: FeatureImportance[];
}

const categoryColors = {
  cognitive: 'bg-category-cognitive',
  biomarker: 'bg-category-biomarker',
  imaging: 'bg-category-imaging',
  clinical: 'bg-category-clinical',
};

const categoryLabels = {
  cognitive: 'Cognitive',
  biomarker: 'Biomarker',
  imaging: 'Imaging',
  clinical: 'Clinical',
};

export const FeatureImportanceChart = ({ features }: FeatureImportanceChartProps) => {
  const maxImportance = Math.max(...features.map(f => f.importance));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="section-header mb-0">
          <span className="w-2 h-2 rounded-full bg-primary" />
          Feature Importance (SHAP Values)
        </h3>
        
        {/* Legend */}
        <div className="flex items-center gap-3">
          {Object.entries(categoryLabels).map(([key, label]) => (
            <div key={key} className="flex items-center gap-1.5">
              <div className={cn("w-2 h-2 rounded-full", categoryColors[key as keyof typeof categoryColors])} />
              <span className="text-xs text-muted-foreground">{label}</span>
            </div>
          ))}
        </div>
      </div>
      
      <div className="space-y-3">
        {features.map((feature, index) => (
          <div 
            key={feature.feature} 
            className="group animate-fade-in"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  categoryColors[feature.category]
                )} />
                <span className="text-sm text-foreground">{feature.feature}</span>
              </div>
              <div className="flex items-center gap-2">
                {feature.direction === 'positive' ? (
                  <ArrowUp className="w-3 h-3 text-destructive" />
                ) : (
                  <ArrowDown className="w-3 h-3 text-success" />
                )}
                <span className="font-mono text-sm text-muted-foreground">
                  {(feature.importance * 100).toFixed(1)}%
                </span>
              </div>
            </div>
            <div className="h-3 bg-muted/50 rounded-full overflow-hidden">
              <div 
                className={cn(
                  "h-full rounded-full transition-all duration-1000 ease-out",
                  categoryColors[feature.category]
                )}
                style={{ width: `${(feature.importance / maxImportance) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      
      <div className="pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground">
          <span className="text-foreground font-medium">Interpretation:</span> Features with 
          <ArrowUp className="w-3 h-3 text-destructive inline mx-1" /> 
          increase risk prediction, while 
          <ArrowDown className="w-3 h-3 text-success inline mx-1" />
          decrease it. Bar length indicates relative importance in the model's decision.
        </p>
      </div>
    </div>
  );
};
