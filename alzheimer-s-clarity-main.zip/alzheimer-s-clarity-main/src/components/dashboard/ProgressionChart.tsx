import { ProgressionDataPoint } from '@/types/patient';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { cn } from '@/lib/utils';

interface ProgressionChartProps {
  data: ProgressionDataPoint[];
  patientName: string;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const dataPoint = payload[0].payload;
    const hasActual = dataPoint.cognitiveScore !== null;
    
    return (
      <div className="glass-panel-strong p-3 shadow-lg">
        <p className="text-sm font-medium text-foreground mb-2">Month {label}</p>
        {hasActual && (
          <div className="flex items-center gap-2 text-sm">
            <div className="w-2 h-2 rounded-full bg-primary" />
            <span className="text-muted-foreground">Actual:</span>
            <span className="font-mono text-foreground">{dataPoint.cognitiveScore}</span>
          </div>
        )}
        <div className="flex items-center gap-2 text-sm">
          <div className="w-2 h-2 rounded-full bg-info" />
          <span className="text-muted-foreground">Predicted:</span>
          <span className="font-mono text-foreground">{dataPoint.predictedScore.toFixed(1)}</span>
        </div>
        <div className="text-xs text-muted-foreground mt-1">
          95% CI: [{dataPoint.confidenceLower.toFixed(1)} - {dataPoint.confidenceUpper.toFixed(1)}]
        </div>
      </div>
    );
  }
  return null;
};

export const ProgressionChart = ({ data, patientName }: ProgressionChartProps) => {
  // Find the last actual data point
  const lastActualIndex = data.findIndex(d => d.cognitiveScore === null) - 1;
  const currentMonth = lastActualIndex >= 0 ? data[lastActualIndex].month : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="section-header mb-0">
          <span className="w-2 h-2 rounded-full bg-primary" />
          Cognitive Progression Forecast
        </h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-primary rounded" />
            <span className="text-muted-foreground">Actual</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-info rounded" />
            <span className="text-muted-foreground">Predicted</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-6 h-3 bg-info/20 rounded" />
            <span className="text-muted-foreground">95% CI</span>
          </div>
        </div>
      </div>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="confidenceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(199, 89%, 48%)" stopOpacity={0.2} />
                <stop offset="95%" stopColor="hsl(199, 89%, 48%)" stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(174, 72%, 45%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(174, 72%, 45%)" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(217, 33%, 17%)" />
            <XAxis 
              dataKey="month" 
              tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 12 }}
              axisLine={{ stroke: 'hsl(217, 33%, 17%)' }}
              tickLine={{ stroke: 'hsl(217, 33%, 17%)' }}
              label={{ value: 'Months', position: 'insideBottom', offset: -5, fill: 'hsl(215, 20%, 55%)' }}
            />
            <YAxis 
              domain={[0, 30]}
              tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 12 }}
              axisLine={{ stroke: 'hsl(217, 33%, 17%)' }}
              tickLine={{ stroke: 'hsl(217, 33%, 17%)' }}
              label={{ value: 'MMSE Score', angle: -90, position: 'insideLeft', fill: 'hsl(215, 20%, 55%)' }}
            />
            <Tooltip content={<CustomTooltip />} />
            
            {/* Confidence interval area */}
            <Area
              type="monotone"
              dataKey="confidenceUpper"
              stroke="none"
              fill="url(#confidenceGradient)"
            />
            <Area
              type="monotone"
              dataKey="confidenceLower"
              stroke="none"
              fill="hsl(var(--background))"
            />
            
            {/* Predicted line */}
            <Area
              type="monotone"
              dataKey="predictedScore"
              stroke="hsl(199, 89%, 48%)"
              strokeWidth={2}
              strokeDasharray="5 5"
              fill="none"
            />
            
            {/* Actual data line */}
            <Area
              type="monotone"
              dataKey="cognitiveScore"
              stroke="hsl(174, 72%, 45%)"
              strokeWidth={3}
              fill="url(#actualGradient)"
              dot={{ fill: 'hsl(174, 72%, 45%)', strokeWidth: 0, r: 4 }}
              activeDot={{ fill: 'hsl(174, 72%, 45%)', strokeWidth: 2, stroke: 'hsl(var(--background))', r: 6 }}
            />
            
            {/* Current time reference line */}
            <ReferenceLine 
              x={currentMonth} 
              stroke="hsl(38, 92%, 50%)" 
              strokeDasharray="3 3"
              label={{ value: 'Today', position: 'top', fill: 'hsl(38, 92%, 50%)', fontSize: 11 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
        <div className="text-center">
          <p className="text-xs text-muted-foreground mb-1">Current Score</p>
          <p className="text-xl font-mono font-bold text-foreground">
            {data.find(d => d.cognitiveScore !== null && d.month === currentMonth)?.cognitiveScore || 'N/A'}
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground mb-1">12-Month Forecast</p>
          <p className="text-xl font-mono font-bold text-info">
            {data.find(d => d.month === currentMonth + 12)?.predictedScore.toFixed(1) || 'N/A'}
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground mb-1">36-Month Forecast</p>
          <p className="text-xl font-mono font-bold text-info">
            {data[data.length - 1]?.predictedScore.toFixed(1) || 'N/A'}
          </p>
        </div>
      </div>
    </div>
  );
};
