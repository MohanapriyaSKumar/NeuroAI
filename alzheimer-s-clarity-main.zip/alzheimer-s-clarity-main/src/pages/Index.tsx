import { useState } from 'react';
import { Sidebar } from '@/components/dashboard/Sidebar';
import { OverviewSection } from '@/components/dashboard/OverviewSection';
import { PatientAnalysisSection } from '@/components/dashboard/PatientAnalysisSection';
import { EthicsSection } from '@/components/dashboard/EthicsSection';
import { MethodologySection } from '@/components/dashboard/MethodologySection';
import { Patient } from '@/types/patient';
import { Helmet } from 'react-helmet-async';

const Index = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  const handlePatientSelect = (patient: Patient) => {
    setSelectedPatient(patient);
    setActiveSection('patients');
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return <OverviewSection onPatientSelect={handlePatientSelect} />;
      case 'patients':
        return (
          <PatientAnalysisSection 
            selectedPatient={selectedPatient} 
            onPatientSelect={setSelectedPatient} 
          />
        );
      case 'predictions':
        return (
          <PatientAnalysisSection 
            selectedPatient={selectedPatient} 
            onPatientSelect={setSelectedPatient} 
          />
        );
      case 'explainability':
        return (
          <PatientAnalysisSection 
            selectedPatient={selectedPatient} 
            onPatientSelect={setSelectedPatient} 
          />
        );
      case 'ethics':
        return <EthicsSection />;
      case 'methodology':
        return <MethodologySection />;
      default:
        return <OverviewSection onPatientSelect={handlePatientSelect} />;
    }
  };

  return (
    <>
      <Helmet>
        <title>NeuroAI - Explainable AI for Alzheimer's Detection</title>
        <meta 
          name="description" 
          content="Advanced AI-powered system for early detection and progression forecasting of Alzheimer's Disease with explainable predictions and clinical decision support."
        />
      </Helmet>
      
      <div className="flex min-h-screen bg-background">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        
        <main className="flex-1 p-8 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
            {renderSection()}
          </div>
        </main>
      </div>
    </>
  );
};

export default Index;
