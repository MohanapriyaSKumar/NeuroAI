import { CognitiveScore } from '@/types/patient';
import { cn } from '@/lib/utils';
import { TrendingDown, TrendingUp, Minus } from 'lucide-react';

interface CognitiveScoresPanelProps {
  scores: CognitiveScore[];
}

const TrendIcon = ({ trend }: { trend: 'stable' | 'declining' | 'improving' }) => {
  if (trend === 'declining') return <TrendingDown className="w-4 h-4 text-destructive" />;
  if (trend === 'improving') return <TrendingUp className="w-4 h-4 text-success" />;
  return <Minus className="w-4 h-4 text-muted-foreground" />;
};

const trendLabels = {
  stable: 'Stable',
  declining: 'Declining',
  improving: 'Improving',
};

const trendColors = {
  stable: 'text-muted-foreground',
  declining: 'text-destructive',
  improving: 'text-success',
};

export const CognitiveScoresPanel = ({ scores }: CognitiveScoresPanelProps) => {
  return (
    <div className="space-y-4">
      <h3 className="section-header">
        <span className="w-2 h-2 rounded-full bg-category-cognitive" />
        Cognitive Assessment Scores
      </h3>
      
      <div className="grid grid-cols-2 gap-3">
        {scores.map((score, index) => {
          const percentage = (score.value / score.maxValue) * 100;
          const isLow = percentage < 70;
          
          return (
            <div 
              key={score.name}
              className={cn(
                "p-4 rounded-lg border bg-card transition-all animate-fade-in hover:border-primary/30",
                isLow ? "border-warning/30" : "border-border"
              )}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-foreground">{score.name}</span>
                <div className="flex items-center gap-1.5">
                  <TrendIcon trend={score.trend} />
                  <span className={cn("text-xs", trendColors[score.trend])}>
                    {trendLabels[score.trend]}
                  </span>
                </div>
              </div>
              
              <div className="flex items-baseline gap-1 mb-3">
                <span className="text-2xl font-mono font-bold text-foreground">{score.value}</span>
                <span className="text-sm text-muted-foreground">/ {score.maxValue}</span>
              </div>
              
              {/* Progress bar */}
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className={cn(
                    "h-full rounded-full transition-all duration-1000",
                    percentage >= 80 ? "bg-success" :
                    percentage >= 60 ? "bg-warning" : "bg-destructive"
                  )}
                  style={{ width: `${percentage}%` }}
                />
              </div>
              
              <p className="text-xs text-muted-foreground mt-2">
                {percentage >= 80 ? "Within normal range" :
                 percentage >= 60 ? "Borderline - monitoring recommended" :
                 "Below normal - clinical attention needed"}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
