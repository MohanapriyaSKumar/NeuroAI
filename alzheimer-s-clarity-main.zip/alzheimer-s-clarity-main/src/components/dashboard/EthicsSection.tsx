import { Shield, AlertTriangle, CheckCircle, Users, Lock, Eye, Scale, Heart } from 'lucide-react';
import { cn } from '@/lib/utils';

const principles = [
  {
    icon: Shield,
    title: 'Patient Privacy',
    description: 'All data is de-identified and encrypted. We follow HIPAA guidelines and implement strict access controls.',
    status: 'implemented',
  },
  {
    icon: Scale,
    title: 'Fairness & Bias Mitigation',
    description: 'Model tested across age, gender, and demographic groups. Continuous monitoring for disparate impact.',
    status: 'implemented',
  },
  {
    icon: Eye,
    title: 'Transparency',
    description: 'All predictions come with explainable AI insights. Clinicians can understand why decisions are made.',
    status: 'implemented',
  },
  {
    icon: Users,
    title: 'Human Oversight',
    description: 'AI serves as decision support only. Final clinical decisions always rest with qualified healthcare professionals.',
    status: 'implemented',
  },
];

const limitations = [
  {
    title: 'Not a Diagnostic Tool',
    description: 'This system provides risk assessments and decision support, not medical diagnoses. Always consult with qualified healthcare professionals.',
  },
  {
    title: 'Data Dependencies',
    description: 'Predictions rely on the quality and completeness of input data. Missing or inaccurate data may affect results.',
  },
  {
    title: 'Population Generalization',
    description: 'Model trained on specific populations. Performance may vary for underrepresented groups.',
  },
  {
    title: 'Temporal Limitations',
    description: 'Progression forecasts are probabilistic estimates based on historical patterns and may not account for all individual factors.',
  },
];

const biasMetrics = [
  { group: 'Gender', metric: 'Equal Opportunity Difference', value: 0.02, threshold: 0.1, status: 'pass' },
  { group: 'Age Group', metric: 'Demographic Parity Ratio', value: 0.95, threshold: 0.8, status: 'pass' },
  { group: 'Ethnicity', metric: 'Equalized Odds Difference', value: 0.04, threshold: 0.1, status: 'pass' },
  { group: 'Education', metric: 'Calibration by Group', value: 0.03, threshold: 0.1, status: 'pass' },
];

export const EthicsSection = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3">
          <Shield className="w-7 h-7 text-primary" />
          Ethics & Responsible AI
        </h2>
        <p className="text-muted-foreground max-w-3xl">
          Our commitment to ethical AI development ensures that this tool serves patients and clinicians 
          responsibly, with transparency, fairness, and respect for human dignity.
        </p>
      </div>

      {/* Ethical Principles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {principles.map((principle, index) => (
          <div 
            key={principle.title}
            className="card-elevated p-6 animate-fade-in"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
                <principle.icon className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold text-foreground">{principle.title}</h3>
                  <CheckCircle className="w-4 h-4 text-success" />
                </div>
                <p className="text-sm text-muted-foreground">{principle.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bias Monitoring */}
      <div className="card-elevated p-6">
        <h3 className="section-header">
          <Scale className="w-5 h-5 text-primary" />
          Fairness & Bias Monitoring
        </h3>
        <p className="text-sm text-muted-foreground mb-6">
          Continuous monitoring of model performance across demographic groups to ensure equitable outcomes.
        </p>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Protected Group</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Fairness Metric</th>
                <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Value</th>
                <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Threshold</th>
                <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {biasMetrics.map((metric) => (
                <tr key={`${metric.group}-${metric.metric}`} className="border-b border-border/50">
                  <td className="py-3 px-4 text-sm text-foreground">{metric.group}</td>
                  <td className="py-3 px-4 text-sm text-muted-foreground">{metric.metric}</td>
                  <td className="py-3 px-4 text-center">
                    <span className="font-mono text-sm text-foreground">{metric.value}</span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="font-mono text-sm text-muted-foreground">{'<'} {metric.threshold}</span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className={cn(
                      "inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium",
                      metric.status === 'pass' 
                        ? "bg-success/20 text-success" 
                        : "bg-destructive/20 text-destructive"
                    )}>
                      {metric.status === 'pass' ? (
                        <>
                          <CheckCircle className="w-3 h-3" />
                          Pass
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3 h-3" />
                          Review
                        </>
                      )}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Limitations */}
      <div className="card-elevated p-6 border-warning/30 bg-warning/5">
        <h3 className="section-header">
          <AlertTriangle className="w-5 h-5 text-warning" />
          Important Limitations
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {limitations.map((limitation, index) => (
            <div 
              key={limitation.title}
              className="p-4 rounded-lg bg-background/50 border border-border"
            >
              <h4 className="font-medium text-foreground mb-2">{limitation.title}</h4>
              <p className="text-sm text-muted-foreground">{limitation.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Clinical Use Statement */}
      <div className="card-elevated p-6 border-primary/30">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Heart className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Clinical Use Statement</h3>
            <p className="text-sm text-muted-foreground">
              This AI system is designed as a <strong>clinical decision support tool</strong>, not a replacement for 
              professional medical judgment. All risk assessments and predictions should be reviewed by qualified 
              healthcare professionals in the context of the patient's complete clinical picture. The final 
              responsibility for patient care decisions rests solely with the treating clinician.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
