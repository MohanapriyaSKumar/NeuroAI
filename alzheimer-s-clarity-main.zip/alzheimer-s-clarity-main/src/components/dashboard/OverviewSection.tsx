import { Users, AlertTriangle, Activity, Brain, Target, Clock } from 'lucide-react';
import { StatsCard } from './StatsCard';
import { RiskDistributionChart } from './RiskDistributionChart';
import { dashboardStats, mockPatients } from '@/data/mockPatientData';
import { Patient } from '@/types/patient';

interface OverviewSectionProps {
  onPatientSelect: (patient: Patient) => void;
}

export const OverviewSection = ({ onPatientSelect }: OverviewSectionProps) => {
  const highRiskPatients = mockPatients.filter(p => p.riskLevel === 'high');

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Dashboard Overview</h2>
        <p className="text-muted-foreground">
          Real-time monitoring and analysis of patient cognitive health assessments
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Patients"
          value={dashboardStats.totalPatients}
          subtitle="In active monitoring"
          icon={Users}
          trend={{ value: 12, direction: 'up' }}
        />
        <StatsCard
          title="High Risk"
          value={dashboardStats.highRiskPatients}
          subtitle="Require attention"
          icon={AlertTriangle}
          variant="danger"
        />
        <StatsCard
          title="Model Accuracy"
          value={`${dashboardStats.modelAccuracy}%`}
          subtitle="Cross-validated"
          icon={Target}
          variant="primary"
        />
        <StatsCard
          title="Recent Assessments"
          value={dashboardStats.recentAssessments}
          subtitle="Last 7 days"
          icon={Clock}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Distribution */}
        <div className="card-elevated p-6">
          <h3 className="section-header">
            <span className="w-2 h-2 rounded-full bg-primary" />
            Patient Risk Distribution
          </h3>
          <RiskDistributionChart stats={dashboardStats} />
        </div>

        {/* High Risk Patients */}
        <div className="card-elevated p-6">
          <h3 className="section-header">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            High Risk Patients
          </h3>
          <div className="space-y-3">
            {highRiskPatients.map((patient) => (
              <button
                key={patient.id}
                onClick={() => onPatientSelect(patient)}
                className="w-full flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/20 hover:border-destructive/40 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center">
                    <span className="text-sm font-mono font-bold text-destructive">
                      {patient.riskScore}
                    </span>
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-foreground">{patient.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {patient.diagnosis} • {patient.age}y • Last: {new Date(patient.lastAssessment).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Activity className="w-4 h-4 text-destructive" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Model Performance */}
      <div className="card-elevated p-6">
        <h3 className="section-header">
          <Brain className="w-4 h-4 text-primary" />
          Model Performance Metrics
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center p-4 rounded-lg bg-muted/30">
            <p className="metric-value text-primary">94.2%</p>
            <p className="metric-label mt-1">Accuracy</p>
          </div>
          <div className="text-center p-4 rounded-lg bg-muted/30">
            <p className="metric-value text-success">0.96</p>
            <p className="metric-label mt-1">ROC-AUC</p>
          </div>
          <div className="text-center p-4 rounded-lg bg-muted/30">
            <p className="metric-value text-info">91.8%</p>
            <p className="metric-label mt-1">Sensitivity</p>
          </div>
          <div className="text-center p-4 rounded-lg bg-muted/30">
            <p className="metric-value text-warning">89.4%</p>
            <p className="metric-label mt-1">Specificity</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-4">
          Model validated on 5-fold cross-validation with balanced class weights. 
          Optimized for high sensitivity to minimize false negatives in early detection.
        </p>
      </div>
    </div>
  );
};
