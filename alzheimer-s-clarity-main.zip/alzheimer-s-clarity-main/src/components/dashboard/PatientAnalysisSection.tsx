import { useState } from 'react';
import { mockPatients } from '@/data/mockPatientData';
import { Patient } from '@/types/patient';
import { PatientCard } from './PatientCard';
import { RiskGauge } from './RiskGauge';
import { DiagnosisProbability } from './DiagnosisProbability';
import { CognitiveScoresPanel } from './CognitiveScoresPanel';
import { BiomarkerPanel } from './BiomarkerPanel';
import { FeatureImportanceChart } from './FeatureImportanceChart';
import { ProgressionChart } from './ProgressionChart';
import { Badge } from '@/components/ui/badge';
import { Calendar, FileText, User } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PatientAnalysisSectionProps {
  selectedPatient: Patient | null;
  onPatientSelect: (patient: Patient) => void;
}

const diagnosisBadgeStyles = {
  Normal: 'bg-success/20 text-success border-success/30',
  MCI: 'bg-warning/20 text-warning border-warning/30',
  AD: 'bg-destructive/20 text-destructive border-destructive/30',
};

export const PatientAnalysisSection = ({ selectedPatient, onPatientSelect }: PatientAnalysisSectionProps) => {
  const patient = selectedPatient || mockPatients[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
      {/* Patient List */}
      <div className="lg:col-span-4 space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Patient Cohort</h3>
        <div className="space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto pr-2">
          {mockPatients.map((p) => (
            <PatientCard
              key={p.id}
              patient={p}
              onClick={() => onPatientSelect(p)}
              isSelected={patient.id === p.id}
            />
          ))}
        </div>
      </div>

      {/* Patient Details */}
      <div className="lg:col-span-8 space-y-6">
        {/* Patient Header */}
        <div className="card-elevated p-6">
          <div className="flex items-start gap-6">
            <RiskGauge score={patient.riskScore} level={patient.riskLevel} size="lg" />
            
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-bold text-foreground">{patient.name}</h2>
                <Badge className={cn(diagnosisBadgeStyles[patient.diagnosis])}>
                  {patient.diagnosis}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Age:</span>
                  <span className="text-foreground font-medium">{patient.age} years</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">Gender:</span>
                  <span className="text-foreground font-medium">{patient.gender}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Last:</span>
                  <span className="text-foreground font-medium">
                    {new Date(patient.lastAssessment).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Next:</span>
                  <span className="text-primary font-medium">
                    {new Date(patient.nextAssessment).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="mt-4 p-3 rounded-lg bg-muted/30 flex items-start gap-2">
                <FileText className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                <p className="text-sm text-muted-foreground">{patient.notes}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Diagnosis Probability */}
        <div className="card-elevated p-6">
          <DiagnosisProbability probabilities={patient.diagnosisProbabilities} />
        </div>

        {/* Scores Row */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <div className="card-elevated p-6">
            <CognitiveScoresPanel scores={patient.cognitiveScores} />
          </div>
          <div className="card-elevated p-6">
            <BiomarkerPanel biomarkers={patient.biomarkers} />
          </div>
        </div>

        {/* Progression Chart */}
        <div className="card-elevated p-6">
          <ProgressionChart data={patient.progressionData} patientName={patient.name} />
        </div>

        {/* Feature Importance */}
        <div className="card-elevated p-6">
          <FeatureImportanceChart features={patient.featureImportance} />
        </div>
      </div>
    </div>
  );
};
