import { Database, Cpu, BarChart3, Brain, GitBranch, Layers, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

const pipelineSteps = [
  {
    icon: Database,
    title: 'Data Collection',
    description: 'Longitudinal patient data including cognitive assessments (MMSE, CDR, MoCA), CSF biomarkers, and optional neuroimaging features.',
    details: ['Clinical assessments', 'Biomarker panels', 'Demographic data', 'Medical history'],
  },
  {
    icon: Layers,
    title: 'Preprocessing',
    description: 'Data cleaning, normalization, and feature engineering to prepare inputs for machine learning models.',
    details: ['Missing value imputation', 'Feature scaling', 'Outlier detection', 'Temporal alignment'],
  },
  {
    icon: GitBranch,
    title: 'Feature Engineering',
    description: 'Domain-driven feature creation combining clinical knowledge with data-driven insights.',
    details: ['Biomarker ratios', 'Cognitive decline rates', 'Risk factor composites', 'Temporal features'],
  },
  {
    icon: Cpu,
    title: 'Model Training',
    description: 'Ensemble approach combining gradient boosting and neural networks for robust predictions.',
    details: ['XGBoost classifier', 'Neural network ensemble', '5-fold cross-validation', 'Hyperparameter tuning'],
  },
  {
    icon: Brain,
    title: 'Explainability Layer',
    description: 'SHAP values and attention mechanisms provide interpretable explanations for each prediction.',
    details: ['SHAP values', 'Feature importance', 'Local explanations', 'Counterfactual analysis'],
  },
  {
    icon: BarChart3,
    title: 'Evaluation',
    description: 'Rigorous validation using clinically meaningful metrics and fairness assessments.',
    details: ['ROC-AUC analysis', 'Calibration curves', 'Sensitivity/Specificity', 'Fairness metrics'],
  },
];

const modelDetails = {
  architecture: 'Ensemble (XGBoost + MLP)',
  features: 42,
  trainingSize: '12,847 patients',
  validationMethod: '5-fold stratified CV',
  optimizationTarget: 'Balanced accuracy with sensitivity priority',
};

const datasetInfo = {
  source: 'Multi-center longitudinal cohort study',
  timespan: '2010-2024',
  followUp: 'Mean 4.2 years',
  assessments: '3-6 month intervals',
};

export const MethodologySection = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3">
          <Cpu className="w-7 h-7 text-primary" />
          Methodology & Technical Details
        </h2>
        <p className="text-muted-foreground max-w-3xl">
          A comprehensive overview of the data processing pipeline, model architecture, 
          and evaluation methodology used in this Alzheimer's detection system.
        </p>
      </div>

      {/* Pipeline Steps */}
      <div className="space-y-4">
        <h3 className="section-header">
          <Zap className="w-5 h-5 text-primary" />
          Processing Pipeline
        </h3>
        
        <div className="relative">
          {/* Connection line */}
          <div className="absolute left-6 top-12 bottom-12 w-0.5 bg-border hidden lg:block" />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {pipelineSteps.map((step, index) => (
              <div 
                key={step.title}
                className="card-elevated p-6 animate-fade-in relative"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Step number */}
                <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <step.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-2">{step.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{step.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {step.details.map((detail) => (
                        <span key={detail} className="feature-pill">
                          {detail}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Model & Dataset Info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Model Details */}
        <div className="card-elevated p-6">
          <h3 className="section-header">
            <Cpu className="w-5 h-5 text-primary" />
            Model Architecture
          </h3>
          
          <div className="space-y-4">
            {Object.entries(modelDetails).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between py-2 border-b border-border/50">
                <span className="text-sm text-muted-foreground capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
                <span className="text-sm font-medium text-foreground">{value}</span>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 rounded-lg bg-muted/30">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Why Ensemble?</strong> Combining gradient boosting with neural networks 
              provides robust performance across diverse patient profiles while maintaining interpretability through SHAP integration.
            </p>
          </div>
        </div>

        {/* Dataset Info */}
        <div className="card-elevated p-6">
          <h3 className="section-header">
            <Database className="w-5 h-5 text-primary" />
            Dataset Overview
          </h3>
          
          <div className="space-y-4">
            {Object.entries(datasetInfo).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between py-2 border-b border-border/50">
                <span className="text-sm text-muted-foreground capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
                <span className="text-sm font-medium text-foreground">{value}</span>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 rounded-lg bg-muted/30">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Data Quality:</strong> All records undergo rigorous quality control 
              with standardized assessment protocols and multi-site harmonization procedures.
            </p>
          </div>
        </div>
      </div>

      {/* Feature Categories */}
      <div className="card-elevated p-6">
        <h3 className="section-header">
          <Layers className="w-5 h-5 text-primary" />
          Feature Categories
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-lg bg-category-cognitive/10 border border-category-cognitive/30">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full bg-category-cognitive" />
              <h4 className="font-medium text-foreground">Cognitive (12)</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              MMSE, CDR, MoCA, ADAS-Cog, executive function, memory recall, attention, language
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-category-biomarker/10 border border-category-biomarker/30">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full bg-category-biomarker" />
              <h4 className="font-medium text-foreground">Biomarker (8)</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Amyloid-β42, Total Tau, p-Tau181, NfL, GFAP, inflammatory markers
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-category-imaging/10 border border-category-imaging/30">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full bg-category-imaging" />
              <h4 className="font-medium text-foreground">Imaging (10)</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Hippocampal volume, cortical thickness, white matter lesions, ventricular size
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-category-clinical/10 border border-category-clinical/30">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full bg-category-clinical" />
              <h4 className="font-medium text-foreground">Clinical (12)</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Age, gender, education, family history, cardiovascular health, lifestyle factors
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
