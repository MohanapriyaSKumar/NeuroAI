import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { DashboardStats } from '@/types/patient';

interface RiskDistributionChartProps {
  stats: DashboardStats;
}

const COLORS = {
  low: 'hsl(158, 64%, 42%)',
  moderate: 'hsl(38, 92%, 50%)',
  high: 'hsl(0, 72%, 51%)',
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-panel-strong p-3 shadow-lg">
        <p className="text-sm font-medium text-foreground">{payload[0].name}</p>
        <p className="text-lg font-mono font-bold text-foreground">{payload[0].value} patients</p>
        <p className="text-xs text-muted-foreground">
          {((payload[0].value / payload[0].payload.total) * 100).toFixed(1)}% of cohort
        </p>
      </div>
    );
  }
  return null;
};

export const RiskDistributionChart = ({ stats }: RiskDistributionChartProps) => {
  const data = [
    { name: 'Low Risk', value: stats.lowRiskPatients, total: stats.totalPatients, color: COLORS.low },
    { name: 'Moderate Risk', value: stats.moderateRiskPatients, total: stats.totalPatients, color: COLORS.moderate },
    { name: 'High Risk', value: stats.highRiskPatients, total: stats.totalPatients, color: COLORS.high },
  ];

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={4}
            dataKey="value"
            stroke="none"
          >
            {data.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={entry.color}
                className="transition-all duration-300 hover:opacity-80"
              />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            verticalAlign="bottom" 
            height={36}
            formatter={(value) => <span className="text-sm text-muted-foreground">{value}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};
