import { Biomarker } from '@/types/patient';
import { cn } from '@/lib/utils';
import { AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';

interface BiomarkerPanelProps {
  biomarkers: Biomarker[];
}

const categoryIcons = {
  normal: CheckCircle,
  elevated: AlertTriangle,
  abnormal: AlertCircle,
};

const categoryStyles = {
  normal: { bg: 'bg-success/10', border: 'border-success/30', text: 'text-success', icon: 'text-success' },
  elevated: { bg: 'bg-warning/10', border: 'border-warning/30', text: 'text-warning', icon: 'text-warning' },
  abnormal: { bg: 'bg-destructive/10', border: 'border-destructive/30', text: 'text-destructive', icon: 'text-destructive' },
};

export const BiomarkerPanel = ({ biomarkers }: BiomarkerPanelProps) => {
  return (
    <div className="space-y-4">
      <h3 className="section-header">
        <span className="w-2 h-2 rounded-full bg-category-biomarker" />
        Biomarker Analysis
      </h3>
      
      <div className="grid grid-cols-2 gap-3">
        {biomarkers.map((biomarker, index) => {
          const Icon = categoryIcons[biomarker.category];
          const styles = categoryStyles[biomarker.category];
          
          // Calculate position within range
          const range = biomarker.normalRange.max - biomarker.normalRange.min;
          const position = ((biomarker.value - biomarker.normalRange.min) / range) * 100;
          const clampedPosition = Math.max(0, Math.min(100, position));
          
          return (
            <div 
              key={biomarker.name}
              className={cn(
                "p-4 rounded-lg border transition-all animate-fade-in",
                styles.bg, styles.border
              )}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm font-medium text-foreground">{biomarker.name}</p>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-xl font-mono font-bold text-foreground">
                      {biomarker.value}
                    </span>
                    <span className="text-xs text-muted-foreground">{biomarker.unit}</span>
                  </div>
                </div>
                <Icon className={cn("w-5 h-5", styles.icon)} />
              </div>
              
              {/* Range indicator */}
              <div className="space-y-1">
                <div className="h-2 bg-muted rounded-full relative overflow-hidden">
                  {/* Normal range indicator */}
                  <div 
                    className="absolute h-full bg-success/30 rounded-full"
                    style={{ 
                      left: `${(biomarker.normalRange.min / (biomarker.normalRange.max * 1.5)) * 100}%`,
                      width: `${((biomarker.normalRange.max - biomarker.normalRange.min) / (biomarker.normalRange.max * 1.5)) * 100}%`
                    }}
                  />
                  {/* Current value indicator */}
                  <div 
                    className={cn(
                      "absolute w-3 h-3 rounded-full -top-0.5 transform -translate-x-1/2 border-2 border-background",
                      biomarker.category === 'normal' ? 'bg-success' : 
                      biomarker.category === 'elevated' ? 'bg-warning' : 'bg-destructive'
                    )}
                    style={{ left: `${Math.min(95, clampedPosition)}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{biomarker.normalRange.min}</span>
                  <span className="text-success">Normal Range</span>
                  <span>{biomarker.normalRange.max}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
