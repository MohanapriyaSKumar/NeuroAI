import { cn } from '@/lib/utils';
import { RiskLevel } from '@/types/patient';

interface RiskGaugeProps {
  score: number;
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

const sizeStyles = {
  sm: { container: 'w-24 h-24', stroke: 8, fontSize: 'text-lg' },
  md: { container: 'w-36 h-36', stroke: 10, fontSize: 'text-2xl' },
  lg: { container: 'w-48 h-48', stroke: 12, fontSize: 'text-4xl' },
};

const levelColors = {
  low: { stroke: 'stroke-success', text: 'text-success', glow: 'drop-shadow-[0_0_10px_hsl(var(--success)/0.5)]' },
  moderate: { stroke: 'stroke-warning', text: 'text-warning', glow: 'drop-shadow-[0_0_10px_hsl(var(--warning)/0.5)]' },
  high: { stroke: 'stroke-destructive', text: 'text-destructive', glow: 'drop-shadow-[0_0_10px_hsl(var(--destructive)/0.5)]' },
};

export const RiskGauge = ({ score, level, size = 'md', showLabel = true }: RiskGaugeProps) => {
  const styles = sizeStyles[size];
  const colors = levelColors[level];
  
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 100) * circumference;
  const offset = circumference - progress;

  return (
    <div className={cn("relative flex flex-col items-center", styles.container)}>
      <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
        {/* Background circle */}
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={styles.stroke}
          className="text-muted/30"
        />
        {/* Progress circle */}
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          strokeWidth={styles.stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className={cn(colors.stroke, colors.glow, "transition-all duration-1000 ease-out")}
        />
      </svg>
      
      {/* Center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={cn("font-mono font-bold", styles.fontSize, colors.text)}>
          {score}
        </span>
        {showLabel && (
          <span className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
            Risk Score
          </span>
        )}
      </div>
    </div>
  );
};
